from .user import *
from .recipe import *
from .comment import *
from .rating import *
from .dietary_tag import *
from .cuisine_tag import *
from .recipeIngredient import *
from .favourite import *
